import { Card, CardContent } from "@/components/ui/card";
import { 
  Target, 
  Users, 
  Globe, 
  Award,
  ArrowRight,
  MapPin,
  Calendar,
  TrendingUp
} from "lucide-react";

const About = () => {
  const stats = [
    {
      icon: Users,
      number: "1000+",
      label: "Shifokorlar",
      description: "Platformadan foydalanuvchi mutaxassislar"
    },
    {
      icon: Globe,
      number: "50+",
      label: "Shifoxona",
      description: "Respublika bo'ylab ulangan tibbiy muassasalar"
    },
    {
      icon: Award,
      number: "99.2%",
      label: "Aniqlik",
      description: "AI diagnostika aniqlik darajasi"
    },
    {
      icon: TrendingUp,
      number: "85%",
      label: "Samaradorlik",
      description: "Tashxis qo'yish vaqtini qisqartirish"
    }
  ];

  const benefits = [
    {
      icon: Target,
      title: "Aniq Tashxis",
      description: "CNN va ML algoritmlar yordamida 99.2% aniqlik bilan kasalliklarni aniqlash"
    },
    {
      icon: MapPin,
      title: "Chekka Hududlar",
      description: "Uzoq va qiyin yetib boradigan hududlardagi aholi uchun sifatli tibbiy xizmat"
    },
    {
      icon: Calendar,
      title: "24/7 Xizmat",
      description: "Kun-tun AI asistent shifokorlarga har qanday vaqtda yordam beradi"
    }
  ];

  return (
    <section id="about" className="py-24 bg-background">
      <div className="container mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-medical-secondary/10 text-medical-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Target className="w-4 h-4" />
            Bizning Missiya
          </div>
          
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            <span className="text-medical-primary">O'zbekiston</span> Sog'liqni Saqlash 
            <br />Sohasida Raqamli Transformatsiya
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-4xl mx-auto leading-relaxed">
            TibbiyAI O'zbekistonning har bir burchagida yuqori sifatli tibbiy xizmatni 
            yetkazib berish maqsadida yaratilgan. Bizning platformamiz eng zamonaviy 
            AI texnologiyalarini mahalliy tibbiy ehtiyojlar bilan uyg'unlashtiradi.
          </p>
        </div>

        {/* Main Content Grid */}
        <div className="grid lg:grid-cols-2 gap-16 items-center mb-16">
          {/* Left Content */}
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Zamonaviy Tibbiyot va An'anaviy Tajriba Uyg'unligi
              </h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                TibbiyAI platformasi O'zbek shifokorlarining boy tajribasini sun'iy intellekt 
                imkoniyatlari bilan birlashtiradi. Bu esa tez va aniq tashxis qo'yish, 
                kasalliklarni erta bosqichida aniqlash va eng samarali davolash usullarini 
                tavsiya etishga yordam beradi.
              </p>
              
              <div className="space-y-4">
                {benefits.map((benefit, index) => (
                  <div key={index} className="flex gap-4 p-4 rounded-lg bg-medical-light/30 hover:bg-medical-light/50 transition-colors">
                    <div className="w-10 h-10 bg-medical-primary/20 rounded-lg flex items-center justify-center flex-shrink-0">
                      <benefit.icon className="w-5 h-5 text-medical-primary" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-foreground mb-1">{benefit.title}</h4>
                      <p className="text-sm text-muted-foreground">{benefit.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-6 bg-gradient-to-r from-medical-primary/10 to-medical-secondary/10 rounded-xl border border-medical-primary/20">
              <h4 className="font-bold text-foreground mb-2">Bizning Vazifamiz</h4>
              <p className="text-muted-foreground mb-4">
                O'zbekiston aholisi uchun zamonaviy, qulay va sifatli tibbiy xizmatni 
                sun'iy intellekt yordamida yetkazib berish.
              </p>
              <button className="flex items-center gap-2 text-medical-primary font-medium hover:gap-3 transition-all">
                Batafsil o'qish <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Right Stats */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center p-6 hover:shadow-lg transition-shadow border-0 bg-gradient-to-br from-card to-medical-light/20">
                <CardContent className="p-0">
                  <div className="w-16 h-16 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-xl flex items-center justify-center mx-auto mb-4">
                    <stat.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-medical-primary mb-2">
                    {stat.number}
                  </div>
                  <div className="font-semibold text-foreground mb-2">
                    {stat.label}
                  </div>
                  <div className="text-sm text-muted-foreground">
                    {stat.description}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Vision Section */}
        <div className="bg-gradient-to-r from-medical-primary to-medical-accent rounded-2xl p-8 lg:p-12 text-white">
          <div className="grid lg:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-3xl font-bold mb-6">2030 Yilgacha Bizning Rejalarimiz</h3>
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <p className="font-medium">Barcha viloyat shifoxonalarini ulash</p>
                    <p className="text-medical-light text-sm">14 ta viloyat va Toshkent shahrida to'liq qamrov</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <p className="font-medium">5000+ shifokorni o'qitish</p>
                    <p className="text-medical-light text-sm">AI texnologiyalar bo'yicha keng qamrovli treninglar</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-2 h-2 bg-white rounded-full mt-2 flex-shrink-0" />
                  <div>
                    <p className="font-medium">1 million+ bemor ma'lumotlari</p>
                    <p className="text-medical-light text-sm">Xavfsiz saqlash va tahlil qilish tizimi</p>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center lg:text-right">
              <div className="text-6xl font-bold mb-4">2030</div>
              <div className="text-xl font-medium">Digital Uzbekistan Healthcare</div>
              <div className="text-medical-light mt-2">Raqamli O'zbekiston Sog'liqni Saqlash</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;