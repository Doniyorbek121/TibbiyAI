import { Button } from "@/components/ui/button";
import { ArrowRight, Brain, Activity, Shield } from "lucide-react";
import heroImage from "@/assets/hero-medical-ai.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-medical-primary/10 via-background to-medical-secondary/5" />
      
      <div className="container mx-auto px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 bg-medical-secondary/10 text-medical-primary px-4 py-2 rounded-full text-sm font-medium">
                <Brain className="w-4 h-4" />
                Sun'iy Intellekt Texnologiyasi
              </div>
              
              <h1 className="text-5xl lg:text-7xl font-bold text-foreground leading-tight">
                <span className="bg-gradient-to-r from-medical-primary to-medical-accent bg-clip-text text-transparent">
                  TibbiyAI
                </span>
              </h1>
              
              <h2 className="text-xl lg:text-2xl text-muted-foreground font-light">
                O'zbekiston sog'liqni saqlash sohasida zamonaviy AI platforma
              </h2>
              
              <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl">
                Shifokorlarga tez va aniq tashxis qo'yishda yordam beradigan ilg'or sun'iy intellekt 
                texnologiyalari. CNN, NLP va mashinaviy o'qitish algoritmlari yordamida tibbiy tasvirlarni 
                tahlil qilish va kasalliklarni bashorat qilish.
              </p>
            </div>

            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-gradient-to-r from-medical-primary to-medical-accent hover:opacity-90 transition-opacity group">
                Platforma bilan tanishing
                <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </Button>
              
              <Button variant="outline" size="lg" className="border-medical-primary text-medical-primary hover:bg-medical-primary hover:text-white">
                Demo ko'rish
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 pt-8">
              <div className="text-center">
                <div className="text-2xl font-bold text-medical-primary">99.2%</div>
                <div className="text-sm text-muted-foreground">Aniqlik darajasi</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-medical-primary">50+</div>
                <div className="text-sm text-muted-foreground">Shifoxona</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-medical-primary">24/7</div>
                <div className="text-sm text-muted-foreground">AI Yordam</div>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative">
            <div className="relative">
              <img 
                src={heroImage} 
                alt="TibbiyAI Platform" 
                className="w-full h-auto rounded-2xl shadow-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-medical-primary/20 to-transparent rounded-2xl" />
            </div>
            
            {/* Floating cards */}
            <div className="absolute -top-4 -left-4 bg-card border border-medical-secondary/20 rounded-xl p-4 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-medical-secondary/20 rounded-lg flex items-center justify-center">
                  <Activity className="w-5 h-5 text-medical-primary" />
                </div>
                <div>
                  <div className="text-sm font-medium">Live Monitoring</div>
                  <div className="text-xs text-muted-foreground">Realtime tahlil</div>
                </div>
              </div>
            </div>
            
            <div className="absolute -bottom-4 -right-4 bg-card border border-medical-secondary/20 rounded-xl p-4 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-medical-accent/20 rounded-lg flex items-center justify-center">
                  <Shield className="w-5 h-5 text-medical-accent" />
                </div>
                <div>
                  <div className="text-sm font-medium">Xavfsizlik</div>
                  <div className="text-xs text-muted-foreground">HIPAA uyg'un</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      {/* Animated background elements */}
      <div className="absolute top-1/4 left-1/4 w-72 h-72 bg-medical-secondary/10 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-medical-primary/10 rounded-full blur-3xl animate-pulse delay-1000" />
    </section>
  );
};

export default Hero;