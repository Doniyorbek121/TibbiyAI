import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { 
  Mail, 
  Phone, 
  MapPin, 
  Clock,
  Send,
  MessageCircle,
  Calendar,
  Users
} from "lucide-react";

const Contact = () => {
  const contactInfo = [
    {
      icon: Mail,
      title: "Email",
      content: "info@tibbiyai.uz",
      subtitle: "Bizga yozing",
      color: "text-blue-500"
    },
    {
      icon: Phone,
      title: "Telefon",
      content: "+998 71 123 45 67",
      subtitle: "24/7 qo'llab-quvvatlash",
      color: "text-green-500"
    },
    {
      icon: MapPin,
      title: "Manzil",
      content: "Toshkent, O'zbekiston",
      subtitle: "Yunusobod tumani",
      color: "text-red-500"
    },
    {
      icon: Clock,
      title: "Ish vaqti",
      content: "Dush-Juma 9:00-18:00",
      subtitle: "Shanba 9:00-14:00",
      color: "text-purple-500"
    }
  ];

  const services = [
    {
      icon: MessageCircle,
      title: "Konsultatsiya",
      description: "Bepul AI diagnostika platformasi bo'yicha maslahat"
    },
    {
      icon: Calendar,
      title: "Demo Sessiya",
      description: "Platformaning real imkoniyatlarini ko'ring"
    },
    {
      icon: Users,
      title: "Trening Dasturi",
      description: "Shifokorlar uchun AI texnologiyalar kursi"
    }
  ];

  return (
    <section id="contact" className="py-24 bg-medical-light/30">
      <div className="container mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-medical-secondary/10 text-medical-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Mail className="w-4 h-4" />
            Bog'lanish
          </div>
          
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            <span className="text-medical-primary">TibbiyAI</span> Jamoasi Bilan
            <br />Bog'laning
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            Bizning mutaxassislarimiz platformaning barcha imkoniyatlari haqida 
            batafsil ma'lumot berishga tayyor. Savollaringizni bering!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-16">
          {/* Contact Form */}
          <div>
            <Card className="border-0 shadow-xl bg-card">
              <CardContent className="p-8">
                <h3 className="text-2xl font-bold text-foreground mb-6">
                  Bizga xabar yuboring
                </h3>
                
                <form className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Ism
                      </label>
                      <Input placeholder="Ismingizni kiriting" className="border-medical-primary/20 focus:border-medical-primary" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Familiya
                      </label>
                      <Input placeholder="Familiyangizni kiriting" className="border-medical-primary/20 focus:border-medical-primary" />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Email
                    </label>
                    <Input type="email" placeholder="email@example.com" className="border-medical-primary/20 focus:border-medical-primary" />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Telefon raqam
                    </label>
                    <Input placeholder="+998 90 123 45 67" className="border-medical-primary/20 focus:border-medical-primary" />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Lavozim/Mutaxassislik
                    </label>
                    <Input placeholder="Shifokor, Administrator, va hokazo" className="border-medical-primary/20 focus:border-medical-primary" />
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Xabar
                    </label>
                    <Textarea 
                      placeholder="TibbiyAI platformasi haqida qanday ma'lumot olishni xohlaysiz?"
                      rows={4}
                      className="border-medical-primary/20 focus:border-medical-primary"
                    />
                  </div>
                  
                  <Button className="w-full bg-gradient-to-r from-medical-primary to-medical-secondary hover:opacity-90 text-white">
                    <Send className="w-4 h-4 mr-2" />
                    Xabar yuborish
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>

          {/* Contact Information */}
          <div className="space-y-8">
            {/* Contact Details */}
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6">
                Bog'lanish ma'lumotlari
              </h3>
              
              <div className="grid md:grid-cols-2 gap-4">
                {contactInfo.map((info, index) => (
                  <Card key={index} className="border-0 bg-card hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className={`w-12 h-12 rounded-lg bg-gray-100 flex items-center justify-center`}>
                          <info.icon className={`w-6 h-6 ${info.color}`} />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground mb-1">
                            {info.title}
                          </h4>
                          <p className="text-foreground font-medium">
                            {info.content}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {info.subtitle}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Services */}
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-6">
                Xizmatlarimiz
              </h3>
              
              <div className="space-y-4">
                {services.map((service, index) => (
                  <Card key={index} className="border-0 bg-gradient-to-r from-medical-primary/5 to-medical-secondary/5 hover:from-medical-primary/10 hover:to-medical-secondary/10 transition-all">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <div className="w-10 h-10 bg-medical-primary/20 rounded-lg flex items-center justify-center">
                          <service.icon className="w-5 h-5 text-medical-primary" />
                        </div>
                        <div>
                          <h4 className="font-semibold text-foreground mb-2">
                            {service.title}
                          </h4>
                          <p className="text-muted-foreground">
                            {service.description}
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* CTA */}
            <Card className="border-0 bg-gradient-to-r from-medical-primary to-medical-accent text-white">
              <CardContent className="p-8 text-center">
                <h4 className="text-xl font-bold mb-4">
                  Tezkor javob olish uchun
                </h4>
                <p className="text-medical-light mb-6">
                  Telegram kanalimizga qo'shiling va eng so'nggi yangiliklar, 
                  maslahatlar va texnik qo'llab-quvvatlashni oling.
                </p>
                <Button variant="secondary" className="bg-white text-medical-primary hover:bg-medical-light">
                  <MessageCircle className="w-4 h-4 mr-2" />
                  Telegram kanalga qo'shilish
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;