import { Card, CardContent } from "@/components/ui/card";
import { 
  Brain, 
  Scan, 
  FileText, 
  TrendingUp, 
  Shield, 
  Cloud,
  Users,
  Zap,
  Target
} from "lucide-react";

const features = [
  {
    icon: Brain,
    title: "CNN Tasvir Tahlili",
    description: "Konvolyutsion neyron tarmoqlar yordamida rentgen, KT va MRI tasvirlarni yuqori aniqlik bilan tahlil qilish",
    category: "AI Technology"
  },
  {
    icon: FileText,
    title: "NLP Matn Tahlili",
    description: "Tabiiy tilni qayta ishlash orqali bemor shikoyatlari va kasallik tarixini avtomatik o'rganish",
    category: "Natural Language"
  },
  {
    icon: TrendingUp,
    title: "Kasallik Bashorati",
    description: "Mashinaviy o'qitish algoritmlari yordamida kasalliklarning rivojlanishini oldindan aniqlash",
    category: "Prediction"
  },
  {
    icon: Scan,
    title: "Realtime Diagnostika",
    description: "Bir necha soniya ichida tibbiy tasvirlarni tahlil qilib, tez tashxis natijalarini berish",
    category: "Speed"
  },
  {
    icon: Shield,
    title: "Xavfsiz Ma'lumotlar",
    description: "HIPAA standartlariga mos ravishda bemor ma'lumotlarini shifrlash va xavfsiz saqlash",
    category: "Security"
  },
  {
    icon: Cloud,
    title: "Bulutli Infratuzilma",
    description: "AWS va Azure bulutli xizmatlar orqali yuqori ishonchlilik va miqyoslanuvchi echimlar",
    category: "Infrastructure"
  },
  {
    icon: Users,
    title: "Ko'p Foydalanuvchi",
    description: "Shifokorlar, bemorlar va administratorlar uchun individual interfeys va ruxsatlar tizimi",
    category: "User Management"
  },
  {
    icon: Zap,
    title: "Resurs Optimizatsiyasi",
    description: "Shifoxonalarda resurslarni optimal taqsimlash va ish jarayonlarini avtomatlashtirish",
    category: "Optimization"
  },
  {
    icon: Target,
    title: "Chekka Hududlar",
    description: "O'zbekistonning uzoq va chekka hududlarida tibbiy xizmat sifatini oshirish",
    category: "Accessibility"
  }
];

const Features = () => {
  return (
    <section className="py-24 bg-medical-light/30">
      <div className="container mx-auto px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-medical-secondary/10 text-medical-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Zap className="w-4 h-4" />
            Platforma Imkoniyatlari
          </div>
          
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Zamonaviy <span className="text-medical-primary">AI Texnologiyalari</span>
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            TibbiyAI platformasi eng so'nggi sun'iy intellekt texnologiyalarini qo'llagan holda 
            O'zbekiston sog'liqni saqlash tizimini modernizatsiya qiladi
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="group hover:shadow-xl transition-all duration-300 border-0 bg-gradient-to-br from-card to-medical-light/20 hover:scale-105"
            >
              <CardContent className="p-8">
                <div className="mb-6">
                  <div className="w-16 h-16 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                    <feature.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="text-xs font-medium text-medical-primary mb-2 uppercase tracking-wider">
                    {feature.category}
                  </div>
                  
                  <h3 className="text-xl font-bold text-foreground mb-3">
                    {feature.title}
                  </h3>
                </div>
                
                <p className="text-muted-foreground leading-relaxed">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* CTA Section */}
        <div className="text-center mt-16">
          <div className="bg-gradient-to-r from-medical-primary to-medical-accent rounded-2xl p-8 text-white">
            <h3 className="text-2xl font-bold mb-4">
              TibbiyAI bilan kelajakni bugun boshang
            </h3>
            <p className="text-medical-light mb-6 max-w-2xl mx-auto">
              O'zbekiston sog'liqni saqlash sohasida raqamli transformatsiyaga qo'shiling
            </p>
            <div className="flex gap-4 justify-center">
              <button className="bg-white text-medical-primary px-6 py-3 rounded-lg font-medium hover:bg-medical-light transition-colors">
                Batafsil ma'lumot
              </button>
              <button className="border border-white text-white px-6 py-3 rounded-lg font-medium hover:bg-white/10 transition-colors">
                Demo so'rash
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Features;