import { Card, CardContent } from "@/components/ui/card";
import { 
  Cpu, 
  Database, 
  Network, 
  Lock,
  BarChart3,
  Layers,
  Gauge,
  Globe
} from "lucide-react";

const technologies = [
  {
    icon: Cpu,
    title: "Konvolyutsion Neyron Tarmoqlar",
    subtitle: "CNN Architecture",
    description: "Tibbiy tasvirlarni tahlil qilish uchun maxsus ishlab chiqilgan chuqur o'qitish modellari",
    features: ["ResNet-50 Architecture", "Transfer Learning", "Real-time Processing", "99.2% Accuracy"],
    color: "from-blue-500 to-cyan-500"
  },
  {
    icon: Database,
    title: "Tabiiy Til Qayta Ishlash",
    subtitle: "NLP & Text Analytics",
    description: "O'zbek va rus tillaridagi tibbiy hujjatlarni tahlil qilish va tushunish",
    features: ["BERT Models", "Medical Terminology", "Multilingual Support", "Semantic Analysis"],
    color: "from-green-500 to-emerald-500"
  },
  {
    icon: BarChart3,
    title: "Mashinaviy O'qitish",
    subtitle: "ML Algorithms",
    description: "Kasalliklarni bashorat qilish va tavsiya tizimlarini yaratish",
    features: ["Random Forest", "SVM Classifiers", "Ensemble Methods", "Predictive Analytics"],
    color: "from-purple-500 to-violet-500"
  },
  {
    icon: Network,
    title: "Bulutli Arxitektura",
    subtitle: "Cloud Infrastructure",
    description: "Miqyoslanuvchi va ishonchli bulutli yechimlar",
    features: ["AWS/Azure Integration", "Auto-scaling", "Load Balancing", "99.9% Uptime"],
    color: "from-orange-500 to-red-500"
  }
];

const Technology = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-medical-secondary/10 text-medical-primary px-4 py-2 rounded-full text-sm font-medium mb-4">
            <Layers className="w-4 h-4" />
            Texnologiya Stek
          </div>
          
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-6">
            Ilg'or <span className="text-medical-primary">AI Texnologiyalari</span>
          </h2>
          
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            TibbiyAI platformasi eng zamonaviy sun'iy intellekt va bulutli texnologiyalar 
            asosida qurilgan bo'lib, yuqori samaradorlik va ishonchlilikni ta'minlaydi
          </p>
        </div>

        {/* Technology Cards */}
        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          {technologies.map((tech, index) => (
            <Card key={index} className="group overflow-hidden border-0 bg-gradient-to-br from-card to-medical-light/20 hover:shadow-2xl transition-all duration-500">
              <CardContent className="p-8">
                <div className="flex items-start gap-4 mb-6">
                  <div className={`w-16 h-16 bg-gradient-to-br ${tech.color} rounded-xl flex items-center justify-center group-hover:scale-110 transition-transform`}>
                    <tech.icon className="w-8 h-8 text-white" />
                  </div>
                  
                  <div className="flex-1">
                    <div className="text-sm font-medium text-medical-primary mb-1">
                      {tech.subtitle}
                    </div>
                    <h3 className="text-xl font-bold text-foreground mb-2">
                      {tech.title}
                    </h3>
                    <p className="text-muted-foreground">
                      {tech.description}
                    </p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-2">
                  {tech.features.map((feature, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-sm">
                      <div className="w-1.5 h-1.5 bg-medical-primary rounded-full" />
                      <span className="text-muted-foreground">{feature}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Performance Metrics */}
        <div className="bg-gradient-to-r from-medical-primary/5 via-medical-secondary/5 to-medical-accent/5 rounded-2xl p-8">
          <h3 className="text-2xl font-bold text-center text-foreground mb-8">
            Platforma Ko'rsatkichlari
          </h3>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-medical-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Gauge className="w-8 h-8 text-medical-primary" />
              </div>
              <div className="text-3xl font-bold text-medical-primary mb-2">99.2%</div>
              <div className="text-sm text-muted-foreground">Diagnostika aniqligi</div>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-medical-secondary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Cpu className="w-8 h-8 text-medical-secondary" />
              </div>
              <div className="text-3xl font-bold text-medical-secondary mb-2">&lt;3s</div>
              <div className="text-sm text-muted-foreground">Tahlil vaqti</div>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-medical-accent/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Lock className="w-8 h-8 text-medical-accent" />
              </div>
              <div className="text-3xl font-bold text-medical-accent mb-2">100%</div>
              <div className="text-sm text-muted-foreground">HIPAA muvofiqlik</div>
            </div>
            
            <div className="text-center">
              <div className="w-16 h-16 bg-medical-primary/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-medical-primary" />
              </div>
              <div className="text-3xl font-bold text-medical-primary mb-2">24/7</div>
              <div className="text-sm text-muted-foreground">Xizmat vaqti</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Technology;