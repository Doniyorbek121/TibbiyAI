import { Brain, Mail, Phone, MapPin, Facebook, Instagram, Youtube, Linkedin } from "lucide-react";

const Footer = () => {
  const footerLinks = {
    platform: [
      { name: "Imkoniyatlar", href: "#features" },
      { name: "Texnologiya", href: "#technology" },
      { name: "Xavfsizlik", href: "#security" },
      { name: "API Hujjatlari", href: "#docs" }
    ],
    company: [
      { name: "Biz haqimizda", href: "#about" },
      { name: "Jamoa", href: "#team" },
      { name: "Yangiliklar", href: "#news" },
      { name: "Karyera", href: "#careers" }
    ],
    support: [
      { name: "Yordam markazi", href: "#help" },
      { name: "Bog'lanish", href: "#contact" },
      { name: "Qo'llab-quvvatlash", href: "#support" },
      { name: "Status", href: "#status" }
    ],
    legal: [
      { name: "Maxfiylik siyosati", href: "#privacy" },
      { name: "Xizmat shartlari", href: "#terms" },
      { name: "HIPAA uyg'unligi", href: "#hipaa" },
      { name: "Litsenziya", href: "#license" }
    ]
  };

  const socialLinks = [
    { name: "Facebook", icon: Facebook, href: "#", color: "hover:text-blue-500" },
    { name: "Instagram", icon: Instagram, href: "#", color: "hover:text-pink-500" },
    { name: "LinkedIn", icon: Linkedin, href: "#", color: "hover:text-blue-600" },
    { name: "YouTube", icon: Youtube, href: "#", color: "hover:text-red-500" }
  ];

  return (
    <footer className="bg-medical-dark text-white">
      <div className="container mx-auto px-6 lg:px-8">
        {/* Main Footer Content */}
        <div className="py-16">
          <div className="grid lg:grid-cols-6 gap-8">
            {/* Brand Section */}
            <div className="lg:col-span-2">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-medical-primary to-medical-secondary rounded-xl flex items-center justify-center">
                  <Brain className="w-7 h-7 text-white" />
                </div>
                <div className="font-bold text-2xl">
                  <span className="text-medical-secondary">Tibbiy</span>AI
                </div>
              </div>
              
              <p className="text-gray-300 mb-6 leading-relaxed">
                O'zbekiston sog'liqni saqlash sohasida sun'iy intellekt texnologiyalariga 
                asoslangan zamonaviy platforma. Shifokorlarga tez va aniq tashxis qo'yishda 
                yordam beradi.
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-medical-secondary" />
                  <span className="text-gray-300">info@tibbiyai.uz</span>
                </div>
                <div className="flex items-center gap-3">
                  <Phone className="w-5 h-5 text-medical-secondary" />
                  <span className="text-gray-300">+998 71 123 45 67</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-medical-secondary" />
                  <span className="text-gray-300">Toshkent, O'zbekiston</span>
                </div>
              </div>
            </div>

            {/* Links Sections */}
            <div>
              <h3 className="font-bold text-lg mb-4">Platforma</h3>
              <ul className="space-y-3">
                {footerLinks.platform.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} className="text-gray-300 hover:text-medical-secondary transition-colors">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-4">Kompaniya</h3>
              <ul className="space-y-3">
                {footerLinks.company.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} className="text-gray-300 hover:text-medical-secondary transition-colors">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-4">Qo'llab-quvvatlash</h3>
              <ul className="space-y-3">
                {footerLinks.support.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} className="text-gray-300 hover:text-medical-secondary transition-colors">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h3 className="font-bold text-lg mb-4">Huquqiy</h3>
              <ul className="space-y-3">
                {footerLinks.legal.map((link, index) => (
                  <li key={index}>
                    <a href={link.href} className="text-gray-300 hover:text-medical-secondary transition-colors">
                      {link.name}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Newsletter Section */}
        <div className="border-t border-gray-700 py-8">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="font-bold text-xl mb-2">Yangiliklar xatlarini oling</h3>
              <p className="text-gray-300">
                TibbiyAI platformasining eng so'nggi yangiliklari va xususiyatlari haqida birinchilardan bo'lib xabar oling.
              </p>
            </div>
            <div className="flex gap-4">
              <input
                type="email"
                placeholder="Email manzilingizni kiriting"
                className="flex-1 px-4 py-3 rounded-lg bg-gray-800 border border-gray-600 text-white placeholder-gray-400 focus:outline-none focus:border-medical-secondary"
              />
              <button className="px-6 py-3 bg-gradient-to-r from-medical-primary to-medical-secondary rounded-lg font-medium hover:opacity-90 transition-opacity">
                Obuna bo'lish
              </button>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-700 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <div className="text-gray-300 text-sm">
              © 2024 TibbiyAI. Barcha huquqlar himoyalangan. O'zbekiston Respublikasi.
            </div>
            
            <div className="flex items-center gap-4">
              <span className="text-gray-400 text-sm">Ijtimoiy tarmoqlar:</span>
              <div className="flex gap-3">
                {socialLinks.map((social, index) => (
                  <a
                    key={index}
                    href={social.href}
                    className={`w-10 h-10 bg-gray-800 hover:bg-gray-700 rounded-lg flex items-center justify-center transition-colors ${social.color}`}
                    aria-label={social.name}
                  >
                    <social.icon className="w-5 h-5" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Certification */}
        <div className="border-t border-gray-700 py-6">
          <div className="flex flex-wrap justify-center items-center gap-8 text-sm text-gray-400">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">✓</span>
              </div>
              <span>HIPAA uyg'un</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">✓</span>
              </div>
              <span>ISO 27001 sertifikatlangan</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 bg-purple-500 rounded-full flex items-center justify-center">
                <span className="text-white text-xs font-bold">✓</span>
              </div>
              <span>FDA tasdiqlangan algoritm</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;